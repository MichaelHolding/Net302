//declares variables and modules needed for app
const express = require('express');
const app = express()
const bodyParser = require('body-parser');
const https = require('https');
const urldb = "mongodb://192.168.0.46:27017/"; //url can change based on location of db
const MongoClient = require('mongodb').MongoClient;

//sets the app to listen for requests on port 4000
app.listen(4000, () => console.log('Listening on Port 4000'));


app.use(express.static('public'))
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine','ejs');


app.get('/', function (req, res) {


    MongoClient.connect(urldb,function(err,db){
        if (err) throw err;
        console.log('database connected');
        const dbo = db.db("weatherData");
        const mysort = {timestamp: -1} //sorting db by descending timestamp
        dbo.collection("weatherSearches").find({}).sort(mysort).toArray(function(err,result){
            if (err) throw err;
            console.log(result)
            //renders the search page with the most recent searches as "data"
            res.render('index', {weather: '', data:result, error: ''});
        })
    })


})

app.post('/', function (req, res) {


    let city = req.body.city ? req.body.city : "london" ;
    const url = 'https://api.openweathermap.org/data/2.5/forecast?q='+ city +
        ',UK&APPID=ebe26bc638a996c14150a1c33dd18475&units=metric';

    https.get(url, (response) => {

        if (response.statusCode === 200) {
            response.on("data", (data) => {
                const json = JSON.parse(data);
                //renders the index.ejs file with the weather data populated with the "json" object
                res.render('index', {weather: json,data: '', error: null});
                let timestamp = Date.now();
                MongoClient.connect(urldb,function (err,db){
                    if (err) throw err;
                    const dbo =db.db("weatherData");
                    let myobj = {timestamp: timestamp, city: city };
                    //inserts "myobj" into the database
                    dbo.collection("weatherSearches").insertOne(myobj, function(err,res){
                        if (err) throw err
                        console.log("data entered");
                    })
                })
            })
        } else {
            // no weather data has been received, renders error page
            res.render('index', {weather: "0",data:'',error: 'please check entry'})
        }
    })
})




